const Assignment = require("../models/assignment");
const Asset = require("../models/asset");

exports.createAssignment = async (req, res) => {
    try {
        const { assetId, quantity, assignedTo } = req.body;

        if (!req.user || !req.user.baseId) {
            return res.status(401).json({
                message: "baseId missing from token"
            });
        }

        const baseId = req.user.baseId;

        const asset = await Asset.findOne({ assetId, baseId });

        const assetAtBase = await Asset.findOne({
            _id: assetId,
            baseId: baseId
        });

        if (!assetAtBase) {
            return res.status(404).json({
                message: "Asset not found at this base"
            });
        }

        if (assetAtBase.quantity < quantity) {
            return res.status(400).json({
                message: "Insufficient stock"
            });
        }

        assetAtBase.quantity -= quantity;
        await assetAtBase.save();

        const assignment = await Assignment.create({
            assetId,
            baseId,
            quantity,
            assignedTo
        });

        res.status(201).json({
            success: true,
            assignment
        });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};


exports.getAssignments = async (req, res) => {
    const baseId = req.user.baseId;
    const assignments = await Assignment.find({ baseId }).populate("assetId");
    res.json(assignments);
};
